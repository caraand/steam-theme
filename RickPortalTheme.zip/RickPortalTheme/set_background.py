#!/usr/bin/env python3
"""Ставит свою картинку фоном темы Rick Portal.

  python3 set_background.py ~/Pictures/portal.jpg
  python3 set_background.py ~/Pictures/portal.png --dim 0.35
  python3 set_background.py --reset        # вернуть зелёный портал

Картинка вшивается в src/css/userBackground.css, путь до неё потом не нужен.
После запуска полностью перезапусти Steam.
"""
import argparse, base64, io, mimetypes, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "src" / "css" / "userBackground.css"
DEFAULT = HERE / "src" / "css" / "userBackground.default.css"


def main():
    p = argparse.ArgumentParser(description="Сменить фон темы Rick Portal")
    p.add_argument("image", nargs="?", help="путь к картинке (jpg/png/webp)")
    p.add_argument("--dim", type=float, default=0.45, help="затемнение 0..1 (по умолчанию 0.45)")
    p.add_argument("--max-width", type=int, default=1920, help="ужать до этой ширины (нужен Pillow)")
    p.add_argument("--reset", action="store_true", help="вернуть фон по умолчанию")
    a = p.parse_args()

    if a.reset:
        OUT.write_text(DEFAULT.read_text(encoding="utf-8"), encoding="utf-8")
        print("Фон сброшен на зелёный портал. Перезапусти Steam.")
        return
    if not a.image:
        p.error("укажи путь к картинке или --reset")

    src = Path(a.image).expanduser()
    if not src.is_file():
        sys.exit(f"Файл не найден: {src}")
    dim = min(max(a.dim, 0.0), 1.0)

    try:
        from PIL import Image
        img = Image.open(src).convert("RGB")
        if img.width > a.max_width:
            img = img.resize((a.max_width, round(img.height * a.max_width / img.width)), Image.LANCZOS)
        buf = io.BytesIO()
        img.save(buf, "JPEG", quality=85)
        data, mime = buf.getvalue(), "image/jpeg"
    except ImportError:
        data = src.read_bytes()
        mime = mimetypes.guess_type(src.name)[0] or "image/jpeg"
        print("Pillow не найден: вшиваю как есть (pip install pillow --break-system-packages для сжатия)")

    mb = len(data) / 1024 / 1024
    if mb > 6:
        print(f"Внимание: {mb:.1f} МБ, Steam может тормозить. Лучше картинку поменьше.")

    b64 = base64.b64encode(data).decode("ascii")
    OUT.write_text(f"""/* Сгенерировано set_background.py из {src.name}. Вернуть портал: --reset */
html, body {{
    background-image:
        linear-gradient(rgba(0,0,0,{dim}), rgba(0,0,0,{dim})),
        url("data:{mime};base64,{b64}") !important;
}}
""", encoding="utf-8")
    print(f"Готово: {src.name} ({mb:.2f} МБ), затемнение {dim}. Перезапусти Steam.")


if __name__ == "__main__":
    main()
