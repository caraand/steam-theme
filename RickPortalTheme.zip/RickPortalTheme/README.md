# Rick Portal Theme

Зелёный форк [SpaceTheme](https://github.com/SpaceTheme/Steam) (автор SpaceEnergy, лицензия MIT, см. `LICENSE`).
Что изменено: палитра, логотип и надпись, полупрозрачные панели, свой фон. Вся вёрстка и функции оригинала сохранены.

## Установка
1. Положи папку `RickPortalTheme` в папку тем Millennium (рядом с другими темами).
2. Steam → Настройки → Interface → Open Millennium → Themes → **Rick Portal Theme** → Use.
3. Полностью закрой Steam и запусти заново.

## Свой фон
```
cd <папка тем>/RickPortalTheme
python3 set_background.py ~/Pictures/картинка.jpg
python3 set_background.py ~/Pictures/картинка.jpg --dim 0.3   # светлее
python3 set_background.py --reset                              # вернуть портал
```
Прозрачность панелей: настройки темы в Millennium → General → Other → **Panel transparency**.

## Где что менять
- `src/css/root.css` — цвета темы.
- `src/css/rickBackground.css` — цвета панелей с прозрачностью (держи в соответствии с root.css).
- Остальные настройки оригинальной темы (сайдбар, баннеры, шрифты) остались в меню Millennium.

Иконки грузятся с серверов оригинальной темы (spacetheme.net), нужен интернет при запуске Steam.
